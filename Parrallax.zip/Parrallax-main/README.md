# Parrallax
website of parelleax
#parallax website
.cover > .heading > h1
first-section > h2 > p
.cover2 > second-text
.second-section > h2 > p
.cover3 > third-text
.third-section > h2 > p
.cover-end > .heading >h1
